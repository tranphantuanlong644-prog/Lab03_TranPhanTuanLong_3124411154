LAB 03 - THỰC HÀNH LINQ CƠ BẢN

1. Mở thư mục BaiThucHanhLINQ bằng VS Code.
2. Mở Terminal và chạy: dotnet run
3. Kiểm tra build: dotnet build
4. Chụp ảnh kết quả để chèn vào báo cáo.
5. Đổi MaSV trong tên thư mục và file ZIP thành MSSV thật trước khi nộp.
