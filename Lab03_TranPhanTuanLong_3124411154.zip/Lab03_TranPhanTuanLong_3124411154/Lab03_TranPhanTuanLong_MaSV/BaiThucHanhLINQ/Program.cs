using System;
using System.Collections.Generic;
using System.Linq;

namespace BaiThucHanhLINQ;

class Program
{
    static void Main()
    {
        Console.OutputEncoding = System.Text.Encoding.UTF8;

        Bai21();
        Bai22();
        Bai31();
        Bai32();
        Bai51();
        Bai52();
        Bai62();
    }

    static void TieuDe(string noiDung)
    {
        Console.WriteLine();
        Console.WriteLine(new string('=', 65));
        Console.WriteLine(noiDung);
        Console.WriteLine(new string('=', 65));
    }

    static void InDanhSach<T>(IEnumerable<T> ds) =>
        Console.WriteLine(string.Join(", ", ds));

    static void Bai21()
    {
        TieuDe("BÀI 2.1 - TRUY VẤN MẢNG SỐ NGUYÊN");
        int[] mangSo = { 50, 42, 16, 3, 9, 8, 12, 7, 24, 0 };

        var a = from so in mangSo where so % 4 == 0 && so % 3 == 0 select so;
        var b = mangSo.Where(so => so <= 3);
        var c = mangSo.Select(so => so % 2 == 0 ? so / 2 : so);

        Console.Write("Câu a: "); InDanhSach(a);
        Console.Write("Câu b: "); InDanhSach(b);
        Console.Write("Câu c: "); InDanhSach(c);
    }

    static void Bai22()
    {
        TieuDe("BÀI 2.2 - TRUY VẤN MẢNG CHUỖI");
        string[] mangChuoi = { "đầu", "lòng", "hai", "ả", "tố", "nga", "Thúy", "Kiều", "là", "chị", "em", "là", "Thúy", "Vân" };

        var a = from tu in mangChuoi where tu.Length == 4 orderby tu[0] select tu;
        var b = mangChuoi.Select(tu => $"{tu.ToLower()} - {tu.ToUpper()}");
        var c = mangChuoi.Where(tu => tu.Contains('u') || tu.Contains('ú'));
        var d = mangChuoi.Where(tu => tu.Length > 0 && char.IsUpper(tu[0]));

        Console.Write("Câu a: "); InDanhSach(a);
        Console.WriteLine("Câu b:"); foreach (var x in b) Console.WriteLine("  " + x);
        Console.Write("Câu c: "); InDanhSach(c);
        Console.WriteLine("Câu d: " + string.Join(" ", d));
    }

    static void Bai31()
    {
        TieuDe("BÀI 3.1 - THỐNG KÊ MẢNG SỐ");
        int[] mangSo = { 50, 42, 12, 3, 9, 8, 1, 50, 3, 42, 85 };

        Console.WriteLine($"Câu a: tổng {mangSo.Count()}, chẵn {mangSo.Count(x => x % 2 == 0)}, lẻ {mangSo.Count(x => x % 2 != 0)}");
        Console.WriteLine($"Câu b: tổng {mangSo.Sum()}, lớn nhất {mangSo.Max()}, nhỏ nhất {mangSo.Min()}");
        Console.WriteLine($"Câu c: {mangSo.Distinct().Count()} giá trị khác nhau");
        Console.WriteLine("Câu d:");
        foreach (var g in mangSo.GroupBy(x => x % 5).OrderBy(g => g.Key))
            Console.WriteLine($"  Số dư {g.Key}: {string.Join(", ", g)}");
    }

    static void Bai32()
    {
        TieuDe("BÀI 3.2 - THỐNG KÊ MẢNG CHUỖI");
        string[] monAn = { "Bún bò Huế", "Hủ tiếu heo", "Bánh canh", "Bánh mì", "Nước Cà phê", "Mì quảng", "Cơm tấm", "Nước Chanh dây", "Mì xào", "Bún riêu", "Bánh cuốn", "Mì gói", "Bún chả", "Hủ tiếu Nam vang" };

        int min = monAn.Min(x => x.Length), max = monAn.Max(x => x.Length);
        Console.WriteLine("Câu a:");
        Console.WriteLine("  Ngắn nhất: " + string.Join(", ", monAn.Where(x => x.Length == min)));
        Console.WriteLine("  Dài nhất: " + string.Join(", ", monAn.Where(x => x.Length == max)));
        Console.WriteLine("Câu b:");
        foreach (var g in monAn.GroupBy(x => x.Split(' ')[0]).OrderBy(g => g.Key))
            Console.WriteLine($"  {g.Key}: {string.Join(", ", g)}");
        Console.WriteLine($"Câu c: {monAn.Count(x => x.Split(' ')[0] == "Bánh")} món");
    }

    static void Bai51()
    {
        TieuDe("BÀI 5.1 - TRUY VẤN CƠ BẢN LIST<MONHOC>");
        var ds = DuLieu.DS_Mon();

        var a = ds.Where(m => m.TenMon.StartsWith("Lập trình")).Select(m => m.TenMon);
        var b = ds.Where(m => m.He == "CD").OrderByDescending(m => m.SoTiet).ThenBy(m => m.MaMon);
        var c = ds.Where(m => m.TenMon.Contains("web", StringComparison.OrdinalIgnoreCase)).Select(m => new { m.TenMon, m.He });
        var d = ds.Where(m => m.He == "KTV").OrderBy(m => m.MaMon);

        Console.WriteLine("Câu a:"); foreach (var x in a) Console.WriteLine("  " + x);
        Console.WriteLine("Câu b:"); foreach (var x in b) Console.WriteLine($"  {x.MaMon} | {x.TenMon} | {x.SoTiet}");
        Console.WriteLine("Câu c:"); foreach (var x in c) Console.WriteLine($"  {x.TenMon} | {x.He}");
        Console.WriteLine("Câu d:"); foreach (var x in d) Console.WriteLine($"  {x.MaMon} | {x.TenMon}");
    }

    static void Bai52()
    {
        TieuDe("BÀI 5.2 - THỐNG KÊ LIST<MONHOC>");
        var ds = DuLieu.DS_Mon();

        Console.WriteLine($"Câu a: {ds.Count} môn");
        Console.WriteLine($"Câu b: {ds.Count(m => m.TenMon.StartsWith("Lập trình"))} môn");
        Console.WriteLine($"Câu c: {ds.Where(m => m.He == "KTV").Sum(m => m.SoTiet)} tiết");

        Console.WriteLine("Câu d:");
        foreach (var x in ds.GroupBy(m => HienThiHe(m.He)).Select(g => new { He = g.Key, Tong = g.Count() }))
            Console.WriteLine($"  {x.He}: {x.Tong} môn");

        Console.WriteLine("Câu e:");
        foreach (var x in ds.GroupBy(m => m.SoTiet).OrderByDescending(g => g.Key))
            Console.WriteLine($"  {x.Key} tiết: {x.Count()} môn");

        byte max = ds.Max(m => m.SoTiet);
        Console.WriteLine("Câu f:");
        foreach (var m in ds.Where(m => m.SoTiet == max)) Console.WriteLine("  " + MoTa(m));

        Console.WriteLine("Câu g:");
        foreach (var g in ds.GroupBy(m => HienThiHe(m.He)))
            Console.WriteLine($"  {g.Key}: {g.Count()} môn, tổng {g.Sum(m => m.SoTiet)}, max {g.Max(m => m.SoTiet)}, min {g.Min(m => m.SoTiet)}");

        Console.WriteLine("Câu h:");
        foreach (var g in ds.GroupBy(m => HienThiHe(m.He)).OrderBy(g => g.Key))
            Console.WriteLine($"  {g.Key}: {string.Join(", ", g.OrderBy(m => m.MaMon).Select(m => m.MaMon))}");

        Console.WriteLine("Câu i:");
        foreach (var g in ds.GroupBy(m => m.SoTiet).OrderBy(g => g.Key))
            Console.WriteLine($"  {g.Key} tiết: {string.Join(", ", g.Select(m => m.MaMon))}");

        Console.WriteLine("Câu j:");
        foreach (var g in ds.Where(m => m.He == "KTV").GroupBy(m => m.MaMon[..3]).OrderBy(g => g.Key))
            Console.WriteLine($"  {g.Key}: {string.Join(", ", g.OrderBy(m => m.MaMon).Select(m => m.MaMon))}");

        Console.WriteLine("Câu k:");
        foreach (var g in ds.Where(m => m.SoTiet > 40).GroupBy(m => HienThiHe(m.He)).OrderBy(g => g.Key))
            Console.WriteLine($"  {g.Key}: {string.Join(", ", g.OrderBy(m => m.MaMon).Select(m => m.MaMon))}");
    }

    static void Bai62()
    {
        TieuDe("BÀI 6.2 - JOIN HAI NGUỒN DỮ LIỆU");
        var mons = DuLieu.DS_Mon();
        var hes = DuLieu.DS_He();

        var a = from h in hes join m in mons on h.MaHe equals m.He select new { h.TenHe, m.MaMon, m.TenMon };
        Console.WriteLine("Câu a:"); foreach (var x in a) Console.WriteLine($"  {x.TenHe} | {x.MaMon} | {x.TenMon}");

        var b = from h in hes join m in mons on h.MaHe equals m.He into gm from m in gm.DefaultIfEmpty()
                select new { h.MaHe, h.TenHe, MaMon = m?.MaMon ?? "Chưa có môn", TenMon = m?.TenMon ?? "Chưa có môn học" };
        Console.WriteLine("Câu b:"); foreach (var x in b) Console.WriteLine($"  {x.MaHe} | {x.TenHe} | {x.MaMon} | {x.TenMon}");

        var monKhongHe = from m in mons join h in hes on m.He equals h.MaHe into gh from h in gh.DefaultIfEmpty() where h == null
                         select new { MaHe = "Chưa khai báo", TenHe = "Chưa khai báo hệ", m.MaMon, m.TenMon };
        var c = b.Select(x => new { x.MaHe, x.TenHe, x.MaMon, x.TenMon }).Concat(monKhongHe);
        Console.WriteLine("Câu c:"); foreach (var x in c) Console.WriteLine($"  {x.MaHe} | {x.TenHe} | {x.MaMon} | {x.TenMon}");

        var heKhongMon = from h in hes join m in mons on h.MaHe equals m.He into gm where !gm.Any()
                         select $"Hệ chưa có môn: {h.MaHe} - {h.TenHe}";
        var monKhongHeText = monKhongHe.Select(x => $"Môn chưa khai báo hệ: {x.MaMon} - {x.TenMon}");
        Console.WriteLine("Câu d:"); foreach (var x in heKhongMon.Concat(monKhongHeText)) Console.WriteLine("  " + x);

        var e = (from m in mons join h in hes on m.He equals h.MaHe into gh from h in gh.DefaultIfEmpty()
                 orderby m.SoTiet descending, m.MaMon
                 select new { TenHe = h?.TenHe ?? "Chưa khai báo hệ", m.MaMon, m.TenMon, m.SoTiet }).Take(5);
        Console.WriteLine("Câu e:"); foreach (var x in e) Console.WriteLine($"  {x.TenHe} | {x.MaMon} | {x.TenMon} | {x.SoTiet}");

        var f = from h in hes join m in mons on h.MaHe equals m.He into gm select new { h.MaHe, h.TenHe, Tong = gm.Count() };
        Console.WriteLine("Câu f:"); foreach (var x in f) Console.WriteLine($"  {x.MaHe} | {x.TenHe} | {x.Tong}");

        Console.WriteLine($"Câu g: {mons.Select(m => m.SoTiet).Distinct().Count()} loại số tiết");
        Console.WriteLine("Câu h: " + MoTa(mons.First(m => m.TenMon.StartsWith("Lập trình"))));

        Console.WriteLine("Câu i:");
        foreach (var h in hes)
        {
            var ds = mons.Where(m => m.He == h.MaHe).OrderBy(m => m.MaMon)
                         .Select((m, i) => $"{i + 1}. {m.MaMon} - {m.TenMon}");
            Console.WriteLine($"  {h.MaHe} - {h.TenHe}");
            foreach (var x in ds) Console.WriteLine("    " + x);
            if (!ds.Any()) Console.WriteLine("    Chưa có môn học");
        }
    }

    static string HienThiHe(string he) => string.IsNullOrWhiteSpace(he) ? "Chưa khai báo" : he;
    static string MoTa(MonHoc m) => $"{m.MaMon} | {m.TenMon} | {HienThiHe(m.He)} | {m.SoTiet} tiết";
}

public class MonHoc
{
    public string MaMon { get; set; } = "";
    public string TenMon { get; set; } = "";
    public string He { get; set; } = "";
    public byte SoTiet { get; set; }
}

public class He
{
    public string MaHe { get; set; } = "";
    public string TenHe { get; set; } = "";
}

public static class DuLieu
{
    public static List<MonHoc> DS_Mon() => new()
    {
        new() { MaMon="HP2_1", TenMon="Nền tảng C#", He="KTV", SoTiet=64 },
        new() { MaMon="HP2_2", TenMon="Công nghệ ADO.NET", He="KTV", SoTiet=64 },
        new() { MaMon="HP3_1", TenMon="Lập trình Windows Forms", He="KTV", SoTiet=64 },
        new() { MaMon="HP3_2", TenMon="Xây dựng ứng dụng Windows Forms", He="KTV", SoTiet=64 },
        new() { MaMon="HP4_1", TenMon="Lập trình Web với HTML, CSS và JavaScript", He="KTV", SoTiet=64 },
        new() { MaMon="HP4_2", TenMon="Xây dựng ứng dụng Web với ASP.NET", He="KTV", SoTiet=64 },
        new() { MaMon="HP5_1", TenMon="Lập trình CSDL SQL Server căn bản", He="KTV", SoTiet=64 },
        new() { MaMon="HP5_2", TenMon="Lập trình CSDL SQL Server nâng cao", He="KTV", SoTiet=64 },
        new() { MaMon="JLCB", TenMon="Joomla cơ bản", He="CD", SoTiet=72 },
        new() { MaMon="LINQ", TenMon="Language-Integrated Query", He="CD", SoTiet=64 },
        new() { MaMon="DAWEB", TenMon="Đồ án thực tế Web với ASP.NET", He="CD", SoTiet=40 },
        new() { MaMon="DAWIN", TenMon="Đồ án thực tế Windows Forms", He="CD", SoTiet=40 },
        new() { MaMon="CC++", TenMon="Lập trình hướng đối tượng với C/C++", He="CD", SoTiet=128 },
        new() { MaMon="JQUE", TenMon="JQuery", He="CD", SoTiet=22 },
        new() { MaMon="XML", TenMon="Công nghệ XML", He="CD", SoTiet=32 },
        new() { MaMon="CRYS", TenMon="Crystal Report trong Visual Studio", He="CD", SoTiet=32 },
        new() { MaMon="BWEB", TenMon="HTML, CSS và JavaScript", He="CD", SoTiet=32 },
        new() { MaMon="XYZ", TenMon="Chưa đặt tên môn", He="", SoTiet=0 }
    };

    public static List<He> DS_He() => new()
    {
        new() { MaHe="KTV", TenHe="Kỹ thuật viên" },
        new() { MaHe="CD", TenHe="Chuyên đề" },
        new() { MaHe="QT", TenHe="Chứng chỉ quốc tế" }
    };
}
