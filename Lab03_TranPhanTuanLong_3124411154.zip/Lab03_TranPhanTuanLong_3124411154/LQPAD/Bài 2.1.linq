<Query Kind="Program" />

void Main() 
{ 
    int[] mangSo = { 50, 42, 16, 3, 9, 8, 12, 7, 24, 0 }; 
 
    var cauA = from so in mangSo 
               where so % 4 == 0 && so % 3 == 0 
               select so; 
 
    var cauB = from so in mangSo 
               where so <= 3 
               select so; 
 
    var cauC = from so in mangSo 
               select so % 2 == 0 ? so / 2 : so; 
 
    "Câu a".Dump(); cauA.Dump(); 
    "Câu b".Dump(); cauB.Dump(); 
    "Câu c".Dump(); cauC.Dump(); 
} 