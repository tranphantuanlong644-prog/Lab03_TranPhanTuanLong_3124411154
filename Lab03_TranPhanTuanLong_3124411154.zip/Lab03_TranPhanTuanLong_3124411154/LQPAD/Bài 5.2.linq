<Query Kind="Program" />

void Main()
{
    Bai52();
}

// ======================================================
// BÀI 5.2: THỐNG KÊ TRÊN LIST<MONHOC>
// PHẦN 1: CÂU A ĐẾN CÂU G
// ======================================================
void Bai52()
{
    // Lấy danh sách môn học từ lớp DuLieu
    List<MonHoc> danhSachMon = DuLieu.DS_Mon();

    // ==================================================
    // CÂU A:
    // Cho biết tổng số môn hiện có
    // ==================================================

    int tongSoMon = danhSachMon.Count();

    "========== BÀI 5.2 - CÂU A ==========".Dump();
    $"Tổng số môn hiện có: {tongSoMon}".Dump();


    // ==================================================
    // CÂU B:
    // Đếm số môn có tên bắt đầu bằng "Lập trình"
    // ==================================================

    int soMonLapTrinh = danhSachMon.Count(mon =>
        mon.TenMon.StartsWith("Lập trình"));

    "========== BÀI 5.2 - CÂU B ==========".Dump();

    $"Số môn bắt đầu bằng \"Lập trình\": {soMonLapTrinh}".Dump();


    // ==================================================
    // CÂU C:
    // Tính tổng số tiết của hệ KTV
    // ==================================================

    int tongSoTietKTV = danhSachMon
        .Where(mon => mon.He == "KTV")
        .Sum(mon => mon.SoTiet);

    "========== BÀI 5.2 - CÂU C ==========".Dump();

    $"Tổng số tiết của hệ KTV: {tongSoTietKTV}".Dump();


    // ==================================================
    // CÂU D:
    // Cho biết tổng số môn của mỗi hệ
    // Kết quả gồm Hệ và Tổng số môn
    // ==================================================

    var cauD = danhSachMon
        .GroupBy(mon =>
            string.IsNullOrWhiteSpace(mon.He)
                ? "Chưa khai báo"
                : mon.He)
        .Select(nhom => new
        {
            He = nhom.Key,
            TongSoMon = nhom.Count()
        })
        .OrderBy(ketQua => ketQua.He);

    "========== BÀI 5.2 - CÂU D ==========".Dump();

    cauD.Dump("Tổng số môn của mỗi hệ");


    // ==================================================
    // CÂU E:
    // Nhóm theo số tiết
    // In số tiết và tổng số môn
    // Sắp xếp giảm dần theo số tiết
    // ==================================================

    var cauE = danhSachMon
        .GroupBy(mon => mon.SoTiet)
        .Select(nhom => new
        {
            SoTiet = nhom.Key,
            TongSoMon = nhom.Count()
        })
        .OrderByDescending(ketQua => ketQua.SoTiet);

    "========== BÀI 5.2 - CÂU E ==========".Dump();

    cauE.Dump("Thống kê theo số tiết");


    // ==================================================
    // CÂU F:
    // Thông tin môn học có số tiết cao nhất
    // ==================================================

    byte soTietCaoNhat = danhSachMon.Max(mon => mon.SoTiet);

    // Dùng Where thay vì First để lấy đầy đủ các môn
    // nếu có nhiều môn cùng đạt số tiết cao nhất
    var cauF = danhSachMon
        .Where(mon => mon.SoTiet == soTietCaoNhat);

    "========== BÀI 5.2 - CÂU F ==========".Dump();

    $"Số tiết cao nhất: {soTietCaoNhat}".Dump();

    cauF.Dump("Môn học có số tiết cao nhất");


    // ==================================================
    // CÂU G:
    // Thống kê theo hệ:
    // - Tổng số môn
    // - Tổng số tiết
    // - Số tiết cao nhất
    // - Số tiết thấp nhất
    // ==================================================

    var cauG = danhSachMon
        .GroupBy(mon =>
            string.IsNullOrWhiteSpace(mon.He)
                ? "Chưa khai báo"
                : mon.He)
        .Select(nhom => new
        {
            He = nhom.Key,
            TongSoMon = nhom.Count(),
            TongSoTiet = nhom.Sum(mon => mon.SoTiet),
            SoTietCaoNhat = nhom.Max(mon => mon.SoTiet),
            SoTietThapNhat = nhom.Min(mon => mon.SoTiet)
        })
        .OrderBy(ketQua => ketQua.He);

    "========== BÀI 5.2 - CÂU G ==========".Dump();

    cauG.Dump("Thống kê chi tiết theo hệ");
}


// ======================================================
// LỚP MONHOC
// ======================================================
public class MonHoc
{
    public string MaMon { get; set; } = "";

    public string TenMon { get; set; } = "";

    public string He { get; set; } = "";

    public byte SoTiet { get; set; }
}


// ======================================================
// LỚP DULIEU
// ======================================================
public static class DuLieu
{
    public static List<MonHoc> DS_Mon()
    {
        return new List<MonHoc>
        {
            new MonHoc
            {
                MaMon = "HP2_1",
                TenMon = "Nền tảng C#",
                He = "KTV",
                SoTiet = 64
            },

            new MonHoc
            {
                MaMon = "HP2_2",
                TenMon = "Công nghệ ADO.NET",
                He = "KTV",
                SoTiet = 64
            },

            new MonHoc
            {
                MaMon = "HP3_1",
                TenMon = "Lập trình Windows Forms",
                He = "KTV",
                SoTiet = 64
            },

            new MonHoc
            {
                MaMon = "HP3_2",
                TenMon = "Xây dựng ứng dụng Windows Forms",
                He = "KTV",
                SoTiet = 64
            },

            new MonHoc
            {
                MaMon = "HP4_1",
                TenMon = "Lập trình Web với HTML, CSS và JavaScript",
                He = "KTV",
                SoTiet = 64
            },

            new MonHoc
            {
                MaMon = "HP4_2",
                TenMon = "Xây dựng ứng dụng Web với ASP.NET",
                He = "KTV",
                SoTiet = 64
            },

            new MonHoc
            {
                MaMon = "HP5_1",
                TenMon = "Lập trình CSDL SQL Server căn bản",
                He = "KTV",
                SoTiet = 64
            },

            new MonHoc
            {
                MaMon = "HP5_2",
                TenMon = "Lập trình CSDL SQL Server nâng cao",
                He = "KTV",
                SoTiet = 64
            },

            new MonHoc
            {
                MaMon = "JLCB",
                TenMon = "Joomla cơ bản",
                He = "CD",
                SoTiet = 72
            },

            new MonHoc
            {
                MaMon = "LINQ",
                TenMon = "Language-Integrated Query",
                He = "CD",
                SoTiet = 64
            },

            new MonHoc
            {
                MaMon = "DAWEB",
                TenMon = "Đồ án thực tế Web với ASP.NET",
                He = "CD",
                SoTiet = 40
            },

            new MonHoc
            {
                MaMon = "DAWIN",
                TenMon = "Đồ án thực tế Windows Forms",
                He = "CD",
                SoTiet = 40
            },

            new MonHoc
            {
                MaMon = "CC++",
                TenMon = "Lập trình hướng đối tượng với C/C++",
                He = "CD",
                SoTiet = 128
            },

            new MonHoc
            {
                MaMon = "JQUE",
                TenMon = "JQuery",
                He = "CD",
                SoTiet = 22
            },

            new MonHoc
            {
                MaMon = "XML",
                TenMon = "Công nghệ XML",
                He = "CD",
                SoTiet = 32
            },

            new MonHoc
            {
                MaMon = "CRYS",
                TenMon = "Crystal Report trong Visual Studio",
                He = "CD",
                SoTiet = 32
            },

            new MonHoc
            {
                MaMon = "BWEB",
                TenMon = "HTML, CSS và JavaScript",
                He = "CD",
                SoTiet = 32
            },

            new MonHoc
            {
                MaMon = "XYZ",
                TenMon = "Chưa đặt tên môn",
                He = "",
                SoTiet = 0
            }
        };
    }
}