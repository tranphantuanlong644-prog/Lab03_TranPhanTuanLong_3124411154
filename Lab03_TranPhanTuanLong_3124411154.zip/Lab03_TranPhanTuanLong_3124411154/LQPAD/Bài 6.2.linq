<Query Kind="Program" />

void Main()
{
    Bai62();
}

// ======================================================
// BÀI 6.2: TRUY VẤN TRÊN HAI NGUỒN DỮ LIỆU
// ======================================================
void Bai62()
{
    // Lấy hai nguồn dữ liệu
    List<MonHoc> danhSachMon = DuLieu.DS_Mon();
    List<He> danhSachHe = DuLieu.DS_He();


    // ==================================================
    // CÂU A
    // Dùng join để liệt kê:
    // Tên hệ, mã môn, tên môn
    // ==================================================

    var cauA =
        from he in danhSachHe
        join mon in danhSachMon
            on he.MaHe equals mon.He
        orderby he.MaHe, mon.MaMon
        select new
        {
            he.TenHe,
            mon.MaMon,
            mon.TenMon
        };

    "========== BÀI 6.2 - CÂU A ==========".Dump();
    "Tên hệ, mã môn và tên môn:".Dump();
    cauA.Dump();


    // ==================================================
    // CÂU B
    // Liệt kê cả những hệ chưa có môn học
    // Left outer join bằng GroupJoin và DefaultIfEmpty
    // ==================================================

    var cauB =
        from he in danhSachHe

        join mon in danhSachMon
            on he.MaHe equals mon.He
            into nhomMon

        from mon in nhomMon.DefaultIfEmpty()

        orderby he.MaHe,
                mon == null ? "" : mon.MaMon

        select new
        {
            he.MaHe,
            he.TenHe,

            MaMon = mon == null
                ? "Chưa có môn"
                : mon.MaMon,

            TenMon = mon == null
                ? "Chưa có môn học"
                : mon.TenMon
        };

    "========== BÀI 6.2 - CÂU B ==========".Dump();
    "Danh sách hệ, kể cả hệ chưa có môn học:".Dump();
    cauB.Dump();


    // ==================================================
    // CÂU C
    // Liệt kê:
    // - Hệ chưa có môn học
    // - Môn học chưa khai báo hệ
    //
    // Đây là Full Outer Join
    // LINQ không có trực tiếp Full Outer Join,
    // nên thực hiện hai truy vấn rồi dùng Concat
    // ==================================================

    // Left join từ danh sách hệ sang danh sách môn
    var leftJoinTuHe =
        from he in danhSachHe

        join mon in danhSachMon
            on he.MaHe equals mon.He
            into nhomMon

        from mon in nhomMon.DefaultIfEmpty()

        select new
        {
            MaHe = he.MaHe,
            TenHe = he.TenHe,

            MaMon = mon == null
                ? "Chưa có môn"
                : mon.MaMon,

            TenMon = mon == null
                ? "Chưa có môn học"
                : mon.TenMon
        };

    // Tìm các môn học không có hệ tương ứng
    var monChuaKhaiBaoHe =
        from mon in danhSachMon

        join he in danhSachHe
            on mon.He equals he.MaHe
            into nhomHe

        from he in nhomHe.DefaultIfEmpty()

        where he == null

        select new
        {
            MaHe = string.IsNullOrWhiteSpace(mon.He)
                ? "Chưa khai báo"
                : mon.He,

            TenHe = "Chưa khai báo hệ",
            MaMon = mon.MaMon,
            TenMon = mon.TenMon
        };

    // Ghép hai kết quả thành Full Outer Join
    var cauC = leftJoinTuHe.Concat(monChuaKhaiBaoHe);

    "========== BÀI 6.2 - CÂU C ==========".Dump();
    "Tất cả hệ và môn, kể cả dữ liệu không liên kết:".Dump();
    cauC.Dump();


    // ==================================================
    // CÂU D
    // Chỉ liệt kê:
    // - Những hệ chưa có môn học
    // - Những môn học chưa khai báo hệ
    // ==================================================

    var heChuaCoMon =
        from he in danhSachHe

        join mon in danhSachMon
            on he.MaHe equals mon.He
            into nhomMon

        where !nhomMon.Any()

        select new
        {
            Loai = "Hệ chưa có môn học",
            MaHe = he.MaHe,
            TenHe = he.TenHe,
            MaMon = "",
            TenMon = ""
        };

    var monChuaCoHe =
        from mon in danhSachMon

        join he in danhSachHe
            on mon.He equals he.MaHe
            into nhomHe

        where !nhomHe.Any()

        select new
        {
            Loai = "Môn chưa khai báo hệ",

            MaHe = string.IsNullOrWhiteSpace(mon.He)
                ? "Chưa khai báo"
                : mon.He,

            TenHe = "",
            MaMon = mon.MaMon,
            TenMon = mon.TenMon
        };

    var cauD = heChuaCoMon.Concat(monChuaCoHe);

    "========== BÀI 6.2 - CÂU D ==========".Dump();
    "Các hệ và môn học không liên kết được:".Dump();
    cauD.Dump();


    // ==================================================
    // CÂU E
    // Lấy 5 môn học đầu tiên có số tiết giảm dần
    // Hiển thị:
    // Tên hệ, mã môn, tên môn, số tiết
    // ==================================================

    var cauE =
        (from mon in danhSachMon

         join he in danhSachHe
             on mon.He equals he.MaHe
             into nhomHe

         from he in nhomHe.DefaultIfEmpty()

         orderby mon.SoTiet descending,
                 mon.MaMon ascending

         select new
         {
             TenHe = he == null
                 ? "Chưa khai báo hệ"
                 : he.TenHe,

             mon.MaMon,
             mon.TenMon,
             mon.SoTiet
         })
        .Take(5);

    "========== BÀI 6.2 - CÂU E ==========".Dump();
    "Năm môn học có số tiết cao nhất:".Dump();
    cauE.Dump();


    // ==================================================
    // CÂU F
    // Tổng số môn học của mỗi hệ
    // Hiển thị:
    // Mã hệ, tên hệ, tổng số môn
    // ==================================================

    var cauF =
        from he in danhSachHe

        join mon in danhSachMon
            on he.MaHe equals mon.He
            into nhomMon

        orderby he.MaHe

        select new
        {
            he.MaHe,
            he.TenHe,
            TongSoMon = nhomMon.Count()
        };

    "========== BÀI 6.2 - CÂU F ==========".Dump();
    "Tổng số môn học của từng hệ:".Dump();
    cauF.Dump();


    // ==================================================
    // CÂU G
    // Cho biết có bao nhiêu loại số tiết khác nhau
    // ==================================================

    var cacLoaiSoTiet = danhSachMon
        .Select(mon => mon.SoTiet)
        .Distinct()
        .OrderBy(soTiet => soTiet);

    int soLoaiSoTiet = cacLoaiSoTiet.Count();

    "========== BÀI 6.2 - CÂU G ==========".Dump();

    $"Số loại số tiết khác nhau: {soLoaiSoTiet}".Dump();

    cacLoaiSoTiet.Dump("Danh sách các loại số tiết");


    // ==================================================
    // CÂU H
    // Tìm môn học đầu tiên có tên bắt đầu bằng
    // "Lập trình"
    // ==================================================

    MonHoc? cauH = danhSachMon.FirstOrDefault(mon =>
        mon.TenMon.StartsWith("Lập trình"));

    "========== BÀI 6.2 - CÂU H ==========".Dump();

    if (cauH != null)
    {
        cauH.Dump("Môn học đầu tiên bắt đầu bằng Lập trình");
    }
    else
    {
        "Không tìm thấy môn học phù hợp".Dump();
    }


    // ==================================================
    // CÂU I
    // Liệt kê các môn theo từng hệ
    // Đánh số thứ tự riêng trong mỗi nhóm
    // ==================================================

    var cauI =
        from he in danhSachHe

        join mon in danhSachMon
            on he.MaHe equals mon.He
            into nhomMon

        orderby he.MaHe

        select new
        {
            he.MaHe,
            he.TenHe,

            DanhSachMon = nhomMon
                .OrderBy(mon => mon.MaMon)
                .Select((mon, viTri) => new
                {
                    STT = viTri + 1,
                    mon.MaMon,
                    mon.TenMon,
                    mon.SoTiet
                })
                .ToList()
        };

    "========== BÀI 6.2 - CÂU I ==========".Dump();

    // foreach chỉ dùng để xuất cấu trúc từng nhóm
    foreach (var he in cauI)
    {
        $"HỆ: {he.MaHe} - {he.TenHe}".Dump();

        if (he.DanhSachMon.Any())
        {
            he.DanhSachMon.Dump(
                $"Danh sách môn thuộc hệ {he.MaHe}");
        }
        else
        {
            "Hệ này chưa có môn học".Dump();
        }
    }
}


// ======================================================
// LỚP MONHOC
// Đại diện cho thông tin của một môn học
// ======================================================
public class MonHoc
{
    public string MaMon { get; set; } = "";

    public string TenMon { get; set; } = "";

    public string He { get; set; } = "";

    public byte SoTiet { get; set; }
}


// ======================================================
// LỚP HE
// Đại diện cho thông tin của một hệ đào tạo
// ======================================================
public class He
{
    public string MaHe { get; set; } = "";

    public string TenHe { get; set; } = "";
}


// ======================================================
// LỚP DULIEU
// Cung cấp danh sách môn học và danh sách hệ
// ======================================================
public static class DuLieu
{
    // ==================================================
    // DANH SÁCH MÔN HỌC
    // ==================================================
    public static List<MonHoc> DS_Mon()
    {
        return new List<MonHoc>
        {
            new MonHoc
            {
                MaMon = "HP2_1",
                TenMon = "Nền tảng C#",
                He = "KTV",
                SoTiet = 64
            },

            new MonHoc
            {
                MaMon = "HP2_2",
                TenMon = "Công nghệ ADO.NET",
                He = "KTV",
                SoTiet = 64
            },

            new MonHoc
            {
                MaMon = "HP3_1",
                TenMon = "Lập trình Windows Forms",
                He = "KTV",
                SoTiet = 64
            },

            new MonHoc
            {
                MaMon = "HP3_2",
                TenMon = "Xây dựng ứng dụng Windows Forms",
                He = "KTV",
                SoTiet = 64
            },

            new MonHoc
            {
                MaMon = "HP4_1",
                TenMon = "Lập trình Web với HTML, CSS và JavaScript",
                He = "KTV",
                SoTiet = 64
            },

            new MonHoc
            {
                MaMon = "HP4_2",
                TenMon = "Xây dựng ứng dụng Web với ASP.NET",
                He = "KTV",
                SoTiet = 64
            },

            new MonHoc
            {
                MaMon = "HP5_1",
                TenMon = "Lập trình CSDL SQL Server căn bản",
                He = "KTV",
                SoTiet = 64
            },

            new MonHoc
            {
                MaMon = "HP5_2",
                TenMon = "Lập trình CSDL SQL Server nâng cao",
                He = "KTV",
                SoTiet = 64
            },

            new MonHoc
            {
                MaMon = "JLCB",
                TenMon = "Joomla cơ bản",
                He = "CD",
                SoTiet = 72
            },

            new MonHoc
            {
                MaMon = "LINQ",
                TenMon = "Language-Integrated Query",
                He = "CD",
                SoTiet = 64
            },

            new MonHoc
            {
                MaMon = "DAWEB",
                TenMon = "Đồ án thực tế Web với ASP.NET",
                He = "CD",
                SoTiet = 40
            },

            new MonHoc
            {
                MaMon = "DAWIN",
                TenMon = "Đồ án thực tế Windows Forms",
                He = "CD",
                SoTiet = 40
            },

            new MonHoc
            {
                MaMon = "CC++",
                TenMon = "Lập trình hướng đối tượng với C/C++",
                He = "CD",
                SoTiet = 128
            },

            new MonHoc
            {
                MaMon = "JQUE",
                TenMon = "JQuery",
                He = "CD",
                SoTiet = 22
            },

            new MonHoc
            {
                MaMon = "XML",
                TenMon = "Công nghệ XML",
                He = "CD",
                SoTiet = 32
            },

            new MonHoc
            {
                MaMon = "CRYS",
                TenMon = "Crystal Report trong Visual Studio",
                He = "CD",
                SoTiet = 32
            },

            new MonHoc
            {
                MaMon = "BWEB",
                TenMon = "HTML, CSS và JavaScript",
                He = "CD",
                SoTiet = 32
            },

            // Môn này chưa khai báo hệ
            new MonHoc
            {
                MaMon = "XYZ",
                TenMon = "Chưa đặt tên môn",
                He = "",
                SoTiet = 0
            }
        };
    }


    // ==================================================
    // DANH SÁCH HỆ
    // ==================================================
    public static List<He> DS_He()
    {
        return new List<He>
        {
            new He
            {
                MaHe = "KTV",
                TenHe = "Kỹ thuật viên"
            },

            new He
            {
                MaHe = "CD",
                TenHe = "Chuyên đề"
            },

            // Hệ QT chưa có môn học
            new He
            {
                MaHe = "QT",
                TenHe = "Chứng chỉ quốc tế"
            }
        };
    }
}