<Query Kind="Program" />

void Main()
{
    string[] mangChuoi =
    {
        "đầu", "lòng", "hai", "ả", "tố", "nga",
        "Thúy", "Kiều", "là", "chị", "em", "là",
        "Thúy", "Vân"
    };

    // a
    var cauA =
        from tu in mangChuoi
        where tu.Length == 4
        orderby tu
        select tu;

    "Cau a".Dump();
    cauA.Dump();

    // b
    var cauB =
        from tu in mangChuoi
        select $"{tu.ToLower()} - {tu.ToUpper()}";

    "Cau b".Dump();
    cauB.Dump();

    // c
    var cauC =
        from tu in mangChuoi
        where tu.Contains("ú")
        select tu;

    "Cau c".Dump();
    cauC.Dump();

    // d
    var cauD =
        from tu in mangChuoi
        where char.IsUpper(tu[0])
        select tu;

    "Cau d".Dump();
    string.Join(" ", cauD).Dump();
}