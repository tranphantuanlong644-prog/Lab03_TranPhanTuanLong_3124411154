<Query Kind="Program" />

void Main()
{
    Bai32();
}

void Bai32()
{
    // Khởi tạo mảng tên các món ăn
    string[] monAn =
    {
        "Bún bò Huế",
        "Hủ tiếu heo",
        "Bánh canh",
        "Bánh mì",
        "Nước Cà phê",
        "Mì quảng",
        "Cơm tấm",
        "Nước Chanh dây",
        "Mì xào",
        "Bún riêu",
        "Bánh cuốn",
        "Mì gói",
        "Bún chả",
        "Hủ tiếu Nam vang"
    };

    // =====================================================
    // CÂU A:
    // Tìm các phần tử có chiều dài ngắn nhất và dài nhất
    // =====================================================

    // Tìm độ dài nhỏ nhất trong mảng
    int doDaiNganNhat = monAn.Min(mon => mon.Length);

    // Tìm độ dài lớn nhất trong mảng
    int doDaiDaiNhat = monAn.Max(mon => mon.Length);

    // Lấy tất cả món có độ dài bằng độ dài nhỏ nhất
    var cacMonNganNhat = monAn
        .Where(mon => mon.Length == doDaiNganNhat);

    // Lấy tất cả món có độ dài bằng độ dài lớn nhất
    var cacMonDaiNhat = monAn
        .Where(mon => mon.Length == doDaiDaiNhat);

    "========== BÀI 3.2 - CÂU A ==========".Dump();

    $"Độ dài ngắn nhất: {doDaiNganNhat} ký tự".Dump();

    "Các món có tên ngắn nhất:".Dump();
    cacMonNganNhat.Dump();

    $"Độ dài dài nhất: {doDaiDaiNhat} ký tự".Dump();

    "Các món có tên dài nhất:".Dump();
    cacMonDaiNhat.Dump();


    // =====================================================
    // CÂU B:
    // Phân nhóm theo từ đầu tiên của tên món
    // =====================================================

    var nhomTheoTuDau = monAn
        // Split dùng để tách tên món thành các từ
        // [0] dùng để lấy từ đầu tiên
        .GroupBy(mon => mon.Split(' ')[0])

        // Sắp xếp các nhóm theo từ đầu tiên
        .OrderBy(nhom => nhom.Key);

    "========== BÀI 3.2 - CÂU B ==========".Dump();

    // foreach chỉ được dùng để xuất cấu trúc từng nhóm
    foreach (var nhom in nhomTheoTuDau)
    {
        // Key chính là từ đầu tiên dùng để phân nhóm
        $"Nhóm: {nhom.Key}".Dump();

        // In toàn bộ tên món thuộc nhóm hiện tại
        foreach (var mon in nhom)
        {
            $"  - {mon}".Dump();
        }
    }


    // =====================================================
    // CÂU C:
    // Đếm số phần tử có từ đầu tiên là "Bánh"
    // =====================================================

    int soMonBanh = monAn.Count(mon =>
        mon.Split(' ')[0] == "Bánh");

    "========== BÀI 3.2 - CÂU C ==========".Dump();

    $"Số món có từ đầu tiên là \"Bánh\": {soMonBanh}".Dump();
}