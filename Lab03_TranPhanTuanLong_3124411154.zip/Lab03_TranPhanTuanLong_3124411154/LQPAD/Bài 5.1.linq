<Query Kind="Program" />

void Main()
{
    Bai51();
}

// ======================================================
// BÀI 5.1: TRUY VẤN CƠ BẢN TRÊN LIST<MONHOC>
// ======================================================
void Bai51()
{
    // Lấy danh sách môn học từ lớp DuLieu
    List<MonHoc> danhSachMon = DuLieu.DS_Mon();

    // ==================================================
    // CÂU A
    // Liệt kê tên các môn học bắt đầu bằng "Lập trình"
    // ==================================================

    var cauA_Query =
        from mon in danhSachMon
        where mon.TenMon.StartsWith("Lập trình")
        select mon.TenMon;

    var cauA_Method = danhSachMon
        .Where(mon => mon.TenMon.StartsWith("Lập trình"))
        .Select(mon => mon.TenMon);

    "========== BÀI 5.1 - CÂU A ==========".Dump();
    "Các môn học bắt đầu bằng \"Lập trình\":".Dump();

    cauA_Query.Dump("Query Syntax");

    cauA_Method.Dump("Method Syntax");


    // ==================================================
    // CÂU B
    // Liệt kê các môn thuộc hệ CD
    // Sắp xếp số tiết giảm dần
    // Nếu cùng số tiết thì mã môn tăng dần
    // ==================================================

    var cauB_Query =
        from mon in danhSachMon
        where mon.He == "CD"
        orderby mon.SoTiet descending, mon.MaMon ascending
        select mon;

    var cauB_Method = danhSachMon
        .Where(mon => mon.He == "CD")
        .OrderByDescending(mon => mon.SoTiet)
        .ThenBy(mon => mon.MaMon);

    "========== BÀI 5.1 - CÂU B ==========".Dump();
    "Các môn thuộc hệ CD:".Dump();

    cauB_Query.Dump("Query Syntax");

    cauB_Method.Dump("Method Syntax");


    // ==================================================
    // CÂU C
    // Liệt kê môn có tên chứa từ "web"
    // Không phân biệt chữ hoa và chữ thường
    // Chỉ lấy Tên môn và Hệ
    // ==================================================

    var cauC_Query =
        from mon in danhSachMon
        where mon.TenMon.Contains(
            "web",
            StringComparison.OrdinalIgnoreCase)
        select new
        {
            mon.TenMon,
            mon.He
        };

    var cauC_Method = danhSachMon
        .Where(mon => mon.TenMon.Contains(
            "web",
            StringComparison.OrdinalIgnoreCase))
        .Select(mon => new
        {
            mon.TenMon,
            mon.He
        });

    "========== BÀI 5.1 - CÂU C ==========".Dump();
    "Các môn có tên chứa từ \"web\":".Dump();

    cauC_Query.Dump("Query Syntax");

    cauC_Method.Dump("Method Syntax");


    // ==================================================
    // CÂU D
    // Liệt kê môn thuộc hệ KTV
    // Sắp xếp mã môn tăng dần
    // ==================================================

    var cauD_Query =
        from mon in danhSachMon
        where mon.He == "KTV"
        orderby mon.MaMon ascending
        select mon;

    var cauD_Method = danhSachMon
        .Where(mon => mon.He == "KTV")
        .OrderBy(mon => mon.MaMon);

    "========== BÀI 5.1 - CÂU D ==========".Dump();
    "Các môn thuộc hệ KTV:".Dump();

    cauD_Query.Dump("Query Syntax");

    cauD_Method.Dump("Method Syntax");
}


// ======================================================
// LỚP MONHOC
// Biểu diễn thông tin của một môn học
// ======================================================
public class MonHoc
{
    // Mã môn học
    public string MaMon { get; set; } = "";

    // Tên môn học
    public string TenMon { get; set; } = "";

    // Hệ đào tạo
    public string He { get; set; } = "";

    // Số tiết
    public byte SoTiet { get; set; }
}


// ======================================================
// LỚP DULIEU
// Cung cấp danh sách môn học
// ======================================================
public static class DuLieu
{
    public static List<MonHoc> DS_Mon()
    {
        return new List<MonHoc>
        {
            new MonHoc
            {
                MaMon = "HP2_1",
                TenMon = "Nền tảng C#",
                He = "KTV",
                SoTiet = 64
            },

            new MonHoc
            {
                MaMon = "HP2_2",
                TenMon = "Công nghệ ADO.NET",
                He = "KTV",
                SoTiet = 64
            },

            new MonHoc
            {
                MaMon = "HP3_1",
                TenMon = "Lập trình Windows Forms",
                He = "KTV",
                SoTiet = 64
            },

            new MonHoc
            {
                MaMon = "HP3_2",
                TenMon = "Xây dựng ứng dụng Windows Forms",
                He = "KTV",
                SoTiet = 64
            },

            new MonHoc
            {
                MaMon = "HP4_1",
                TenMon = "Lập trình Web với HTML, CSS và JavaScript",
                He = "KTV",
                SoTiet = 64
            },

            new MonHoc
            {
                MaMon = "HP4_2",
                TenMon = "Xây dựng ứng dụng Web với ASP.NET",
                He = "KTV",
                SoTiet = 64
            },

            new MonHoc
            {
                MaMon = "HP5_1",
                TenMon = "Lập trình CSDL SQL Server căn bản",
                He = "KTV",
                SoTiet = 64
            },

            new MonHoc
            {
                MaMon = "HP5_2",
                TenMon = "Lập trình CSDL SQL Server nâng cao",
                He = "KTV",
                SoTiet = 64
            },

            new MonHoc
            {
                MaMon = "JLCB",
                TenMon = "Joomla cơ bản",
                He = "CD",
                SoTiet = 72
            },

            new MonHoc
            {
                MaMon = "LINQ",
                TenMon = "Language-Integrated Query",
                He = "CD",
                SoTiet = 64
            },

            new MonHoc
            {
                MaMon = "DAWEB",
                TenMon = "Đồ án thực tế Web với ASP.NET",
                He = "CD",
                SoTiet = 40
            },

            new MonHoc
            {
                MaMon = "DAWIN",
                TenMon = "Đồ án thực tế Windows Forms",
                He = "CD",
                SoTiet = 40
            },

            new MonHoc
            {
                MaMon = "CC++",
                TenMon = "Lập trình hướng đối tượng với C/C++",
                He = "CD",
                SoTiet = 128
            },

            new MonHoc
            {
                MaMon = "JQUE",
                TenMon = "JQuery",
                He = "CD",
                SoTiet = 22
            },

            new MonHoc
            {
                MaMon = "XML",
                TenMon = "Công nghệ XML",
                He = "CD",
                SoTiet = 32
            },

            new MonHoc
            {
                MaMon = "CRYS",
                TenMon = "Crystal Report trong Visual Studio",
                He = "CD",
                SoTiet = 32
            },

            new MonHoc
            {
                MaMon = "BWEB",
                TenMon = "HTML, CSS và JavaScript",
                He = "CD",
                SoTiet = 32
            },

            new MonHoc
            {
                MaMon = "XYZ",
                TenMon = "Chưa đặt tên môn",
                He = "",
                SoTiet = 0
            }
        };
    }
}