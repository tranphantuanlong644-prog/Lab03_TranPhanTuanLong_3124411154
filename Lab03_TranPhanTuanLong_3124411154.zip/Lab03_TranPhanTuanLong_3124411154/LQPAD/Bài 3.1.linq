<Query Kind="Program" />

void Main()
{
    Bai31();
}

void Bai31()
{
    int[] mangSo = 
    { 
        50, 42, 12, 3, 9, 8, 1, 50, 3, 42, 85 
    };

    int tongSoPhanTu = mangSo.Count();

    int soPhanTuChan = mangSo.Count(so => so % 2 == 0);

    int soPhanTuLe = mangSo.Count(so => so % 2 != 0);

    "BÀI 3.1 - CÂU A".Dump();

    $"Tổng số phần tử: {tongSoPhanTu}".Dump();

    $"Số phần tử chẵn: {soPhanTuChan}".Dump();

    $"Số phần tử lẻ: {soPhanTuLe}".Dump();
}