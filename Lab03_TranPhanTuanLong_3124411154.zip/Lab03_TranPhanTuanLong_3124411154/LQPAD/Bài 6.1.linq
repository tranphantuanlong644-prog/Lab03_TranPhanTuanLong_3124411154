<Query Kind="Program" />

void Main()
{
    Bai61();
}

// ======================================================
// BÀI 6.1: XÂY DỰNG LỚP HE VÀ DANH SÁCH HỆ
// ======================================================
void Bai61()
{
    // Gọi phương thức DS_He() để lấy danh sách các hệ
    List<He> danhSachHe = DuLieu.DS_He();

    // In nhãn kết quả rõ ràng trước khi xuất dữ liệu
    "========== BÀI 6.1 - DANH SÁCH HỆ ==========".Dump();

    // Hiển thị toàn bộ danh sách hệ
    danhSachHe.Dump("Danh sách hệ đào tạo");

    // In tổng số hệ để kiểm tra dữ liệu
    $"Tổng số hệ: {danhSachHe.Count()}".Dump();
}


// ======================================================
// LỚP HE
// Dùng để biểu diễn thông tin của một hệ đào tạo
// ======================================================
public class He
{
    // Mã hệ, ví dụ: KTV, CD, QT
    public string MaHe { get; set; } = "";

    // Tên đầy đủ của hệ
    public string TenHe { get; set; } = "";
}


// ======================================================
// LỚP DULIEU
// Chứa phương thức khởi tạo danh sách hệ đào tạo
// ======================================================
public static class DuLieu
{
    // Phương thức tĩnh trả về danh sách các hệ
    public static List<He> DS_He()
    {
        return new List<He>
        {
            new He
            {
                MaHe = "KTV",
                TenHe = "Kỹ thuật viên"
            },

            new He
            {
                MaHe = "CD",
                TenHe = "Chuyên đề"
            },

            new He
            {
                MaHe = "QT",
                TenHe = "Chứng chỉ quốc tế"
            }
        };
    }
}